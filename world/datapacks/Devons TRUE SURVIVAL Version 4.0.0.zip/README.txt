		    					Welcome to...

 _________  ________  ___  ___  _______                       ________  ___  ___  ________  ___      ___ ___  ___      ___ ________  ___          
|\___   ___\\   __  \|\  \|\  \|\  ___ \                     |\   ____\|\  \|\  \|\   __  \|\  \    /  /|\  \|\  \    /  /|\   __  \|\  \         
\|___ \  \_\ \  \|\  \ \  \\\  \ \   __/|                    \ \  \___|\ \  \\\  \ \  \|\  \ \  \  /  / | \  \ \  \  /  / | \  \|\  \ \  \        
     \ \  \ \ \   _  _\ \  \\\  \ \  \_|/__                   \ \_____  \ \  \\\  \ \   _  _\ \  \/  / / \ \  \ \  \/  / / \ \   __  \ \  \       
      \ \  \ \ \  \\  \\ \  \\\  \ \  \_|\ \                   \|____|\  \ \  \\\  \ \  \\  \\ \    / /   \ \  \ \    / /   \ \  \ \  \ \  \____  
       \ \__\ \ \__\\ _\\ \_______\ \_______\                    ____\_\  \ \_______\ \__\\ _\\ \__/ /     \ \__\ \__/ /     \ \__\ \__\ \_______\
        \|__|  \|__|\|__|\|_______|\|_______|                   |\_________\|_______|\|__|\|__|\|__|/       \|__|\|__|/       \|__|\|__|\|_______|
                                                                \|_________|                                                                                                                                                                                                                                                                                             	.-- . .-.. -.-. --- -- . / - --- / - .... . / -.-. ..- -- / --.. --- -. .
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		   -BY: DEVON HUGE-
Visit the website here: http://truesurvivalmc.weebly.com/
It contains - Feature Info Wiki
	    - Datapack Download
	    - Resource Pack Download
	    - Community Pages
	    - More

How to install 
---w/ Method #1---
1) Navigate to your .minecraft folder by hitting "WindowsKey" + R, then typing %appdata%.
2) Open .minecraft and find your Saves folder.
3) Drop this zip file into the 'datapacks' folder of your world. 
4) Reload your world and you're done!

---w/ Method #2---
1) Hit Create New World at the Minecraft main menu.
2) Click 'datapacks'. 
3) Click and drag the TRUE SURVIVAL zip folder into the Minecraft game screen.
4) Select TRUE SURVIVAL by clicking the arrow. The icon will move to the right side of the screen.
5) Create your world and you're done!

SPECIAL THANKS:
1) Rapphire from my Discord server for making some of the custom item textures!
2) Arkadyaa on Fiverr for helping me assemble custom model data!
3) To all the people in my Discord who helped, tested, and gave feedback!
4) To the Politiscape lads. May you never see a ghast again. 


~~~~~~~~~~~~~~~~(Creative Commons License)~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
True Survival by Devon Huge is licensed under CC BY-NC-SA 4.0